# Images #

### Add and Modify Pictures ###

Brighten up your application by dragging and dropping images on to the editor.

![alt text](http://appcubator.com/static/img/tutorial/Image_1.png)

- Filepicker - Upload an image to the webpage from your file system, Gmail, Dropbox, Instagram, and Web Images.  

![alt text](http://appcubator.com/static/img/tutorial/Image_Upload.png) 

How do I resize images?

- Click and drag your image boarders to scale your images. 

- Modify the scaling by selecting either the "img-width-fixed" or "img-height-fixed" style. 

- Click on "img-noscale" to preserve your original images resolution. 




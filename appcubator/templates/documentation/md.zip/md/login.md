# Login #

Get users to use your new App! The more the merrier.

![alt text](http://appcubator.com/static/img/tutorial/Elements_1.png)

Login Forms 

- Drag and Drop a 'Login Form' onto your Editor

![alt text](http://appcubator.com/static/img/tutorial/Login_Form.png)

- Click "Edit Login" to open the 'Login Editor'

![alt text](http://appcubator.com/static/img/tutorial/Login_Editor.png)

-  Click on the drop down menu next to 'User goes to' to pick which page of your app your users will be directed to when they login. 

![alt text](http://appcubator.com/static/img/tutorial/Login_Editor2.png)


Social Media Login Button 

- Drag and Drop buttons so users can login to your application with their Facebook, Twitter, and LinkedIn accounts.

![alt text](http://appcubator.com/static/img/tutorial/social_login.png)
# Feedback #


Help us build a better Appcubator!

![alt text](http://appcubator.com/static/img/tutorial/Feedback.png)

Click "Fill the Feedback Form" in Appcubator's homepage. 
# List Editor #

When you drop a "Table List" into the page editor, you are given a blank shell which you can edit. The Lists, display different records of entities based on the user specific database. 

![alt text](http://appcubator.com/static/img/tutorial/Row_Editor.png)

Row Editor
- This will decide what information is displayed to the user and how it is displayed.

- Drag the "Properties" that you would like displayed based on the specific "Table" selected. 

- Add any design elements

Perfect for showing a twitter feed, comment board, or picture gallery.
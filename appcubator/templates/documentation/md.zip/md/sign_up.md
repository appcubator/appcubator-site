# Sign Up #

Get users to use your new App! The more the merrier.

User Sign Up Forms

![alt text](http://appcubator.com/static/img/tutorial/Sign_Up.png)

- Drag and Drop a 'Sign Up' form onto your Editor

- Click "Edit Form" to open the 'Sign Up Form Editor' and edit the labels and placeholders on your form

![alt text](http://appcubator.com/static/img/tutorial/Signup_Editor.png)

How do I change where new users go after signing up?

-  Go to the 'actions on form submission' section of the form editor

- Click on any of the 'Go to' buttons in the options menu to change where new users are directed to after they Sign Up

How do I send welcome emails to new users?

-  Go to the 'actions on form submission' section of the form editor

- Click on any of the 'Send' buttons in the options menu to choose which email sends when the form is submitted

Current sign up route and emails are shown above the options window

![alt text](http://appcubator.com/static/img/tutorial/Signup_Editor2.png)
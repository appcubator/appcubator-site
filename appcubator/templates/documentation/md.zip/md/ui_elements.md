## UI Elements ##


The "UI Elements" toolbar provides you with your Authentication, Current User Entities, Table Data, and Design Elements. Just Drag and Drop what you need.




###Table Data###

![alt text](http://appcubator.com/static/img/tutorial/Elements_3.png)

- Create Form - Allows users to submit information to the database like tweets, pictures

![alt text](http://appcubator.com/static/img/tutorial/Edit_Form.png)

![alt text](http://appcubator.com/static/img/tutorial/Form_Editor.png)

- Table - Coming Soon

- List - Displays different records of entities based on the user specific database. Perfect for showing a twitter feed, comment board, or picture gallery.


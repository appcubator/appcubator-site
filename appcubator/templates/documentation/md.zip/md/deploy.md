## Deploy ##

And We are Live! Share your new Web App with your friends!

![alt text](http://appcubator.com/static/img/tutorial/Deploy_1.png)

Publishing your Application

- Press "Publish" in the editor or "Go to App" to deploy your app to your subdomain or custom domain. And you're live!

![alt text](http://appcubator.com/static/img/tutorial/Deploy_2.png)
 
Download your Web Application's Code

- Click the "The code you have written is available to download here. You will download a .zip file with your code.

![alt text](http://appcubator.com/static/img/tutorial/Code.png)

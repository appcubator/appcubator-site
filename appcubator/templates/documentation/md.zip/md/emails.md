## Emails ##


Send Welcome Emails to your New Users!

![alt text](http://appcubator.com/static/img/tutorial/Emails.png)

Create and send emails to your users. You can add custom user tags to give your messages a personal touch.
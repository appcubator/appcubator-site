# Themes #


We provide a selection of beautiful themes and all the styles will be available in our internal editor. Different themes will give your site a different feel – i.e. minimal, professional, classic, or artistic. 

![alt text](http://appcubator.com/static/img/tutorial/themes.png)

How do I load themes?

![alt text](http://appcubator.com/static/img/tutorial/Themes_2.png)

![alt text](http://appcubator.com/static/img/tutorial/Themes_Blank.png)

- When you are ready to select your theme, click on it and select “Load Theme.” 

![alt text](http://appcubator.com/static/img/tutorial/Themes_Load.png)

- The theme has now been loaded and will be live on your site when you redeploy oyur application.

![alt text](http://appcubator.com/static/img/tutorial/Themes_Purple.png)

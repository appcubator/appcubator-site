## Deleting Your Application ##

How do I delete my application?

- Go to the “Danger Zone” of “Domains & SEO" and press “Delete App”

![alt text](http://appcubator.com/static/img/tutorial/Danger_Zone.png)

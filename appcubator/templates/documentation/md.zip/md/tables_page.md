# Tables Page #

![alt text](http://appcubator.com/static/img/tutorial/User_Table_1.png)

Web applications differ from standard websites in that they allow users to login, store, and access data from 'tables'. 

Users, Tweets, Craigslist posts, Quora questions, Friendships, Likes, Comments, Inventory. These are all examples of 'data' that web applications store in 'tables'.

## Structure of the Data ##

You should think of your data as organized in spreadsheets.
[(Click for more info)](/documentation/user_tables/)
